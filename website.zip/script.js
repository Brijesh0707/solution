document.addEventListener('DOMContentLoaded', function() {
  var viewportWidth = window.innerWidth || document.documentElement.clientWidth;

  if (viewportWidth <= 768) {
    window.location.href = '/responsive.html'; 
  }
});











document.addEventListener('DOMContentLoaded', function() {
  var loginButton = document.getElementById('login1');
  var registerButton = document.getElementById('register1');
  var loginForm = document.getElementById('login2');
  var registerForm = document.getElementById('register2');


  loginForm.style.display = 'block';
  loginButton.style.backgroundColor = 'red';
  loginButton.style.border = '1px solid black';
  loginButton.style.color = 'white';

  loginButton.addEventListener('click', function() {
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
    loginButton.style.backgroundColor = 'red';
    loginButton.style.border = '1px solid black';
    loginButton.style.color = 'white';
    registerButton.style.backgroundColor = '';
    registerButton.style.border = 'none';
    registerButton.style.color = 'black';
  });

  registerButton.addEventListener('click', function() {
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
    loginButton.style.backgroundColor = '';
    loginButton.style.border = 'none';
    loginButton.style.color = 'black';
    registerButton.style.backgroundColor = 'red';
    registerButton.style.border = '1px solid black';
    registerButton.style.color = 'white';
  });
});


function onlogin(){
  alert("Login successfully")
}

function onregister(){
  alert("Register Submited")
}



function searchCandidates() {
  var location = document.getElementById("location").value;
  var jobRole = document.getElementById("job-role").value;
  var candidates = [
    { name: "John Doe", location: "New York", jobRole: "Software Engineer" },

    { name: "Jane Smith", location: "San Francisco", jobRole: "Data Analyst" },
    { name: "David Johnson", location: "London", jobRole: "UX Designer" }
  ];

  var filteredCandidates = candidates.filter(function(candidate) {
    return candidate.location === location && candidate.jobRole === jobRole;
  });

  var candidatesList = document.getElementById("candidates-list");
  candidatesList.innerHTML = "";

  filteredCandidates.forEach(function(candidate) {
    var card = document.createElement("div");
    card.className = "card";

    var detailsDiv = document.createElement("div");
    detailsDiv.className = "details";

    var nameHeading = document.createElement("h3");
    nameHeading.textContent = "Name: " + candidate.name;
    detailsDiv.appendChild(nameHeading);

    var locationHeading = document.createElement("h4");
    locationHeading.textContent = "Location: " + candidate.location;
    detailsDiv.appendChild(locationHeading);

    var jobRoleHeading = document.createElement("h5");
    jobRoleHeading.textContent = "Job Role: " + candidate.jobRole;
    detailsDiv.appendChild(jobRoleHeading);

    var sendButton = document.createElement("button");
    sendButton.textContent = "Send Message";
    sendButton.addEventListener("click", function() {
      sendMessage(candidate.name);
    });

    detailsDiv.appendChild(sendButton);
    card.appendChild(detailsDiv);
    candidatesList.appendChild(card);
  });
}


function sendMessage(candidateName) {
  alert("Message sent to " + candidateName);
}
